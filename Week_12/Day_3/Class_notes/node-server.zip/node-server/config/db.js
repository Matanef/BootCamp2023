const products = [
  { id: 1, name: "iPhone", price: 700 },
  { id: 2, name: "iPad", price: 600 },
  { id: 3, name: "iWatch", price: 500 },
];

const users = [
  { id: 1, name: "John", email: "jjj@gamil.com" },
  { id: 2, name: "Marry", email: "mmm@gmail.com" },
  { id: 3, name: "Dan", email: "ddd@gmail.com" },
];

module.exports = {
  products,
  users,
};
